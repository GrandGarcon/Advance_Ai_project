import pygame
import sys
from math import *
import random

import os
import numpy as np
import tensorflow
import keras
from keras import layers
from keras.models import Model
from keras import backend as K
from keras import utils as np_utils
from keras import optimizers
from keras import activations

#Declaration of constants
dx = 920
dy = 480
gLev = 370

red = (255,0,0)
sky = (180,225,255)
earth = (149,69,53)
star = (255,230,20)
grass = (0,127,50)
black = (0,0,0)
grey = (127,127,127)

#initialize physics
b_acc = 0
c_acc = 0
x = 0
xd = 0
h = 0.1
hd = 0
theta = 0
g = 0.000001
F = 0.000003
l = 150

# Set up the Model
X = layers.Input(shape=(4,))
net = X
net = layers.Dense(32)(net)
net = layers.Activation("relu")(net)
net = layers.Dense(2)(net)
net = layers.Activation("softmax")(net)

model = Model(inputs=X, outputs=net)

model.summary()

# Set up Loss
action_onehot_placeholder = K.placeholder(shape=(None, 2), name="action_onehot")
discount_reward_placeholder = K.placeholder(shape=(None,), name="discount_reward")

action_prob = K.sum(model.output * action_onehot_placeholder, axis=1)
log_action_prob = K.log(action_prob)

loss = - log_action_prob * discount_reward_placeholder
loss = K.mean(loss)

rms = optimizers.rmsprop()
updates = rms.get_updates(params=model.trainable_weights, loss=loss)
train_fn = K.function(inputs=[model.input,
								action_onehot_placeholder,
								discount_reward_placeholder],
								outputs=[],
								updates=updates)

def getAction(s, model):
	s = s.reshape(1,4)
	action_prob = np.squeeze(model.predict(s))
	return np.random.choice(np.arange(2), p=action_prob)

def compute_discounted_R(R, discount_rate=0.99):
    discounted_r = np.zeros_like(R, dtype=np.float32)
    running_add = 0
    for t in reversed(range(len(R))):

        running_add = running_add * discount_rate + R[t]
        discounted_r[t] = running_add

    #discounted_r -= discounted_r.mean() / discounted_r.std()

    return discounted_r

S = []
A = []
R = []

eps = 0.1
gamma = 1.0
a = 1
s = np.array([0,0,0,0])
sprime = np.array([0,0,0,0])
est = 0
Total = 0

#initialize display
pygame.init()
screen = pygame.display.set_mode((dx,dy))
clock = pygame.time.Clock()

while (True):
	dt = clock.tick(60)

	screen.fill(sky)
	pygame.draw.rect(screen, grass, (0,gLev+30,dx,dy-gLev+30), 0)
	pygame.draw.rect(screen, earth, (dx/4-30,gLev,dx/2+60,30), 0)
	pygame.draw.rect(screen, earth, (dx/4-60,gLev-30,30,60), 0)
	pygame.draw.rect(screen, earth, (3*dx/4+60 - 30,gLev-30,30,60), 0)

	xcor = int((x+1)*dx/2)
	ball = (int(xcor + l*cos(pi/2 - theta)), int((gLev-30) - l*sin(pi/2 - theta)))

	pygame.draw.rect(screen, grey, (xcor-30,gLev-30,60,30), 0)
	pygame.draw.circle(screen, red, ball, 20, 0)
	pygame.draw.line(screen, black, (xcor,gLev-15), ball, 3)

	s = np.array([x, xd, h, hd])
	a = getAction(s, model)

	S.append(s)
	A.append(a)

	#Implement the physics
	xdd = 0
	if a == -1 and x > -0.5:
		xdd = -F
	if a == 1 and x < 0.5:
		xdd = F

	hd += (g*sin(theta)*cos(theta) - xdd*cos(theta)*cos(theta)) * dt

	xd += xdd * dt
	x += xd * dt
	h += hd * dt
	if h > 1:
		h = 1
	if h < -1:
		h = -1
	theta = asin(h)

	if x >= 0.5:
		x = 0.5
		xd = 0.0
	if x <= -0.5:
		x = -0.5
		xd = 0.0

	# Obtain reward
	if h <= -1.0 or h >= 1.0:
		print("YOU LOST")
		R.append(-100)

		S = np.array(S)
		A = np.array(A)
		R = np.array(R)

		action_onehot = np_utils.to_categorical(A, num_classes=2)
		discount_reward = compute_discounted_R(R)

		#print(S)
		#print(action_onehot)
		print(discount_reward)
		train_fn([S, action_onehot, discount_reward])
		
		x = 0.0
		xd = 0.0
		h = 0.1
		hd = 0.0
		total_reward = 0
		A = []
		S = []
		R = []
		continue

	R.append(dt/100)

	for event in pygame.event.get():
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE:
				pygame.quit()
				sys.exit()

	pygame.display.update()













