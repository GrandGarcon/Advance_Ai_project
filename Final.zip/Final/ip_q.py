import pygame
import sys
from math import *
import random

import os
import numpy as np
import tensorflow
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras import activations

#Declaration of constants
dx = 920
dy = 480
gLev = 370

red = (255,0,0)
sky = (180,225,255)
earth = (149,69,53)
star = (255,230,20)
grass = (0,127,50)
black = (0,0,0)
grey = (127,127,127)

#initialize physics
b_acc = 0.0
c_acc = 0.0
x = 0.0
xd = 0.0
h = 0.1
hd = 0.0
theta = 0.0
g = 0.000001
F = 0.000003
l = 150

#Set up the Model
model = Sequential()
model.add(Dense(32, input_dim=5, kernel_initializer='random_uniform', activation='relu'))
model.add(Dense(1))
model.compile(loss='mean_squared_error',
              optimizer='sgd',
              metrics=['mae', 'acc'])

def getAction(S, model):
	A = 0
	est = 0.0
	ql = model.predict(np.array([S[0], S[1], S[2], S[3], -1]).reshape(1,5))[0]
	qr = model.predict(np.array([S[0], S[1], S[2], S[3], 1]).reshape(1,5))[0]

	#eps-greedily make selection
	if ql > qr:
		if random.random() > eps:
			A = -1
			est = ql
		else:
			A = 1
			est = qr
	else:
		if random.random() > eps:
			A = 1
			est = qr
		else:
			A = -1
			est = ql

	return A, est

eps = 0.1
gamma = 1.0
A = 1
Aprime = 0
S = [0.0, 0.0, 0.0, 0.0]
Sprime = [0.0, 0.0, 0.0, 0.0]
R = 0.0
est = 0.0

#initialize display
pygame.init()
screen = pygame.display.set_mode((dx,dy))
clock = pygame.time.Clock()

while (True):
	dt = clock.tick(60)

	screen.fill(sky)
	pygame.draw.rect(screen, grass, (0,gLev+30,dx,dy-gLev+30), 0)
	pygame.draw.rect(screen, earth, (dx/4-30,gLev,dx/2+60,30), 0)
	pygame.draw.rect(screen, earth, (dx/4-60,gLev-30,30,60), 0)
	pygame.draw.rect(screen, earth, (3*dx/4+60 - 30,gLev-30,30,60), 0)

	xcor = int((x+1)*dx/2)
	ball = (int(xcor + l*cos(pi/2 - theta)), int((gLev-30) - l*sin(pi/2 - theta)))

	pygame.draw.rect(screen, grey, (xcor-30,gLev-30,60,30), 0)
	pygame.draw.circle(screen, red, ball, 20, 0)
	pygame.draw.line(screen, black, (xcor,gLev-15), ball, 3)

	S[0] = x
	S[1] = xd
	S[2] = h
	S[3] = hd

	xdd = 0
	if A == -1 and x > -0.5:
		xdd = -F
	if A == 1 and x < 0.5:
		xdd = F

	hd += (g*sin(theta)*cos(theta) - xdd*cos(theta)*cos(theta)) * dt

	xd += xdd * dt
	x += xd * dt
	h += hd * dt
	if h > 1:
		h = 1
	if h < -1:
		h = -1
	theta = asin(h)

	if x >= 0.5:
		x = 0.5
		xd = 0.0
	if x <= -0.5:
		x = -0.5
		xd = 0.0

	Sprime[0] = x
	Sprime[1] = xd
	Sprime[2] = h
	Sprime[3] = hd

	if h <= -1.0 or h >= 1.0:
		print("YOU LOST")
		R = -100
		A = 1
		
		x = 0.0
		xd = 0.0
		h = 0.1
		hd = 0.0

		inp = np.array([S[0],S[1],S[2],S[3],A]).reshape(1,5)
		label = np.array([R])
		model.fit(inp, label, verbose=0)
		continue

	R = dt/1000
	
	Aprime, est = getAction(Sprime, model)

	inp = np.array([S[0],S[1], S[2], S[3], A]).reshape(1,5)
	label = np.array([R + gamma*est])
	model.fit(inp, label, verbose=0)

	S = Sprime
	A = Aprime

	for event in pygame.event.get():
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE:
				pygame.quit()
				sys.exit()

	pygame.display.update()













