import pygame
import sys
from math import *
import random

import os
import numpy as np
import tensorflow
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras import activations

#Declaration of constants
dx = 920
dy = 480
rad = 20
gLev = 400

WIN = pi*dx/8+dx/2 - 10
LOSE = -pi*dx/8+dx/2 - 10

red = (255,0,0)
sky = (180,225,255)
earth = (149,69,53)
star = (255,230,20)
green = (0,120,0)
black = (0,0,0)

cvals = [((x*pi/100),cos(x*pi/100)) for x in range(-100,100,1)]
curve = [(x*dx/8 + dx/2,(y-1)*dy/4 + gLev) for (x,y) in cvals]

#initialize physics
ball_pos = 0.0
ball_vel = 0.0
acc = 0.000001
gc = 0.0000015

#Set up the Model
model = Sequential()
model.add(Dense(32, input_dim=3, kernel_initializer='random_uniform', activation='relu'))
model.add(Dense(1))
model.compile(loss='mean_squared_error',
              optimizer='rmsprop',
              metrics=['mae', 'acc'])

model.summary()

def getAction(S, model):
	A = 0
	est = 0.0
	ql = model.predict(np.array([S[0], S[1], -1]).reshape(1,3))[0]
	qr = model.predict(np.array([S[0], S[1], 1]).reshape(1,3))[0]

	#eps-greedily make selection
	if ql > qr:
		if random.random() > eps:
			A = -1
			est = ql
		else:
			A = 1
			est = qr
	else:
		if random.random() > eps:
			A = 1
			est = qr
		else:
			A = -1
			est = ql

	return A, est

eps = 0.1
gamma = 1.0
A = 1
Aprime = 0
S = [0.0, 0.0]
Sprime = [0.0, 0.0]
R = 0.0
est = 0.0

#initialize display
pygame.init()
screen = pygame.display.set_mode((dx,dy))
clock = pygame.time.Clock()

while (True):
	dt = clock.tick(30)

	screen.fill(sky)
	pygame.draw.rect(screen, earth, (0,gLev,dx,dy-gLev), 0)
	pygame.draw.lines(screen, black, False, curve, 3)
	pygame.draw.ellipse(screen, star, (WIN, -dy/2 + gLev - 40 ,20,40), 0)
	pygame.draw.ellipse(screen, red, (LOSE, -dy/2 + gLev - 40 ,20,40), 0)

	S[0] = ball_pos
	S[1] = ball_vel

	if A == -1:
		ball_vel = ball_vel - acc * dt
	if A == 1:
		ball_vel = ball_vel + acc * dt

	ball_vel = ball_vel - gc*sin(ball_pos) * dt
	ball_vel -= (ball_vel * dt * 0.0001)
	ball_pos = ball_pos + ball_vel * dt

	Sprime[0] = ball_pos
	Sprime[1] = ball_vel

	if ball_pos >= pi or ball_pos <= -pi:
		if ball_pos >= pi:
			print("YOU WON")
			R = 100
		elif ball_pos <= -pi:
			print("YOU LOST")
			R = -100
		ball_pos = 0.0
		ball_vel = 0.0
		A = 1		

		x = np.array([S[0],S[1],A]).reshape(1,3)
		y = np.array([R])
		print(x,y)
		model.fit(x, y, verbose=0)
		continue
	
	R = abs(ball_pos) - dt/1000
	
	Aprime, est = getAction(Sprime, model)

	x = np.array([S[0],S[1],A]).reshape(1,3)
	y = np.array([R + gamma*est])
	model.fit(x, y, verbose=0)

	S = Sprime
	A = Aprime

	# QUIT GAME
	for event in pygame.event.get():
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE:
				pygame.quit()
				sys.exit()

	pygame.draw.circle(screen, green, (int(ball_pos*dx/8 + dx/2), \
								 	 int((cos(ball_pos)-1)*dy/4 + gLev - rad)), rad, 0)
	pygame.display.update()













